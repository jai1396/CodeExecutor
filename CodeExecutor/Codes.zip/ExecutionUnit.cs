﻿using Microsoft.CodeAnalysis.CSharp.Scripting;
using Microsoft.CodeAnalysis.Scripting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using System.Collections.Immutable;

namespace CodeExecutor
{
    public class ExecutionUnit
    {
        private string PrevCode;
        private string PrevEditedCode;
        private object[] PrevInputs;
        public object Result { get; private set; }

        private List<Assembly> AsmNames; //will contain assemblies of input objects
        
        private SyntaxTree CurTree;
        private ScriptOptions scriptOptions;

        private List<Assembly> ExtSetRefAssemblies;
        private StringBuilder ExtUsings;
        private string PrevUsings;

        public ExecutionUnit()
        {
            PrevInputs = null;
            Result = null;
            AsmNames = new List<Assembly>();
            CurTree = null;
            scriptOptions = DefaultScriptOptions();
            ExtSetRefAssemblies = new List<Assembly>();
            ExtUsings = new StringBuilder();
            PrevUsings = null;
        }

        // * Assumptions:
        // * 
        // 1 All declarations of wired inputs happen at top of code segment eg
        // * int i;
        // * int b;
        // * string s;
        // * Rat r;
        // * <other code>
        // * 
        // 2 User defined classes do not have System in namespace name
        // * 
        // 3 Wired inputs cannot be declared using var
        // */
        // 1. Explicitly set references(using strong name or path)
        //allow publicly accessible method for references and imports to be set
        //    could accept assemblies or strings
        // 2. Support for expressions without declarations : x.Where( y => y.Text == inputText)
        //do in separate project
        //    get a <name,object> pair and replace their values accordingly to evaluate the expression
        // 3. Get all variable declarations in expressions like the one above.
        //no objects passed
        //    syntactical analysis the main aim
        //    have to try and find out which are the identifiers that would be passed as wired inputs

        public async void Execute(string code, object[] inputs)
        {
            bool asmNamesSame = CompareAsmNames(inputs, PrevInputs);
            
            string CurCode;
            if (asmNamesSame && AreCodesEqual(code, PrevCode))
            {
                CurCode = PrevEditedCode;
            }
            else
            {
                CurCode = EditCode(code);
                if(!asmNamesSame)
                {
                    scriptOptions = ModifyScriptOptions(scriptOptions, CurCode);
                }
            }

            string CurUsings;
            if (asmNamesSame)
            {
                CurUsings = PrevUsings;
            }
            else
            {
                CurUsings = GetCurUsings(AsmNames.Select(asm => asm.GetName().Name));
            }

            var globals = BuildGlobals(inputs);


            string Usings = BuildUsings(ExtUsings.ToString(), CurUsings);

            Console.WriteLine(Usings + CurCode);//comment out

            var state = await CSharpScript.RunAsync(Usings + CurCode, scriptOptions, globals: globals);
            var result = state.ReturnValue;


            Result = result;
            PrevEditedCode = CurCode;
            PrevCode = code;
            PrevInputs = inputs;
            PrevUsings = CurUsings;
        }

        private string BuildUsings(string extUsings, string curUsings)
        {
            return extUsings + "\n" + curUsings;
        }

        private string GetCurUsings(IEnumerable<string> enumerable)
        {
            StringBuilder sb = new StringBuilder();
            foreach (string s in enumerable)
            {
                sb.AppendLine("using " + s + ";");
            }
            return sb.ToString();
        }

        private Globals BuildGlobals(object[] inputs)
        {
            ImmutableArray<object> immutInputs = ImmutableArray.Create<object>(inputs);
            return new Globals(immutInputs);
        }

        private ScriptOptions DefaultScriptOptions()
        {
            return ScriptOptions.Default
                                    .WithImports("System.IO", "System");
        }

        //Looks through the array of inputs
        //Extracts names and types of user defined classes
        //Updates Dictionary<string, Type> ClassNames
        private bool CompareAsmNames(object[] inputs, object[] prevInputs)
        {
            if(inputs == null && prevInputs == null)
            {
                return true;
            }
            else if(inputs == null)
            {
                if (AsmNames.Count > 0) 
                {
                    AsmNames.Clear();
                }
                return false;
            }

            List<string> oldAsmNamesList = new List<string>();
            if(AsmNames.Count!=0)
            {
                oldAsmNamesList = AsmNames.Select(asm => asm.FullName).ToList();
            }

            List<Assembly> newAsmNames = new List<Assembly>();
            foreach (var input in inputs)
            {
                var asm = input.GetType().Assembly;
                var asmName = asm.GetName();
                if (!asmName.FullName.ToString().Contains("mscorlib,") 
                            && !newAsmNames.Any(a => a.GetName().FullName == asmName.FullName))
                {
                    newAsmNames.Add(asm);
                }
               
            }

            List<string> newClassNamesList = new List<string>();
            if(newAsmNames.Count!=0)
            {
                newClassNamesList = newAsmNames.Select(asm => asm.FullName).ToList();
            }

            bool asmNamesSame = oldAsmNamesList.All(newClassNamesList.Contains) && oldAsmNamesList.Count == newClassNamesList.Count;

            if(asmNamesSame==false)
            {
                AsmNames = newAsmNames;
            }

            return asmNamesSame;

        }

        private ScriptOptions ModifyScriptOptions(ScriptOptions scriptOptions, string curCode)
        {
            scriptOptions = AddSOReferences(scriptOptions);
            //scriptOptions = AddSOImports(scriptOptions);
            return scriptOptions;
        }

        //Not implemented AddSOImports
        //private ScriptOptions AddSOImports(ScriptOptions scriptOptions)
        //{
        //    //To implement if using statements or others have to be considered
        //    //or if a function such as Sqrt should be identified as belonging to Math
        //    return scriptOptions;
        //}

        private ScriptOptions AddSOReferences(ScriptOptions scriptOptions)
        {            
            return scriptOptions.AddReferences(AsmNames.ToArray().Distinct());
        }

        //not implemented
        private string EditCode(string code)
        {
            /*string beginClassWrapper = @"class Program{
    public static void Main()
    {
        ";
            string endClassWrapper = @"
    }
}";
            var tree = SyntaxFactory.ParseSyntaxTree(beginClassWrapper + code + endClassWrapper);
            ClassNameRewriter classNameRewriter = new ClassNameRewriter(AsmNames, ExtSetRefAssemblies);
            var newRoot = classNameRewriter.Visit(tree.GetRoot());

            var tempCode = newRoot.ToFullString();
            var newCode = tempCode.Substring(beginClassWrapper.Length, tempCode.Length - beginClassWrapper.Length - endClassWrapper.Length);

            return newCode;*/
            return code;
        }


        //Generates syntax trees for current and previous codes
        //Compares them to test for equality
        private bool AreCodesEqual(string code, string prevCode)
        {
            if(prevCode == null || prevCode == "")
            {
                if(code == null || code == "")
                {
                    return true;
                }
                else
                {
                    CurTree = SyntaxFactory.ParseSyntaxTree(code); 
                    return false;
                }
            }
            var tree = SyntaxFactory.ParseSyntaxTree(code);
            if(tree.IsEquivalentTo(CurTree))
            {
                return true;
            }
            else
            {
                CurTree = tree;
                return false;
            }
        }

        //Fullnames of referenced assemblies must be stored to compare against
        private void AddReferences(object[] references)
        {
            if(references.Length>0)
            {
                references = references.Distinct().ToArray();
                if (references[0] is Assembly)
                {
                    scriptOptions = scriptOptions.AddReferences(Array.ConvertAll(references, item => (Assembly)item));
                    //scriptOptions = scriptOptions.AddReferences((Assembly[])references);
                    foreach (Assembly reference in references)
                    {
                        ExtSetRefAssemblies.Add(reference);
                        ExtUsings.AppendLine("using " + reference.GetName().Name + ";");
                    }
                }
                ExtSetRefAssemblies = ExtSetRefAssemblies.Distinct().ToList();
            }
        }

        //public void AddReferences(params string[] references) => AddReferences((object[])references);
        public void AddReferences(params Assembly[] references) => AddReferences((object[])references);
        //public void AddReferences(params MetadataReference[] references) => AddReferences((object[])references);
        //public void AddReferences(IEnumerable<string> references) => AddReferences((object[])references.ToArray());
        public void AddReferences(IEnumerable<Assembly> references) => AddReferences((object[])references.ToArray());
        //public void AddReferences(IEnumerable<MetadataReference> references) => AddReferences(references.ToArray());

        public void ClearReferences()
        {
            scriptOptions = DefaultScriptOptions();
            ExtSetRefAssemblies.Clear();
            ExtUsings.Clear();
        }

        public void AddImports(string[] imports)
        {
            scriptOptions = scriptOptions.AddImports(imports);
        }

        
    }
}
