﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeExecutor
{
    public class Globals
    {
        //public object[] NI_Input_Object;
        public static string objectArrayName = "NI_Input_Object";
        public ImmutableArray<object> NI_Input_Object;

        //public Globals(object[] arr)
        //{
        //    NI_Input_Object = arr;
        //}

        public Globals(ImmutableArray<object> immutInputs)
        {
            NI_Input_Object = immutInputs;
        }
    }
}
